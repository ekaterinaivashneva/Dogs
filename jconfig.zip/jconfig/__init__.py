# -*- coding: utf-8 -*-
"""
@author: python273
@contact: https://vk.com/python273
@license Apache License, Version 2.0, see LICENSE file

Copyright (C) 2017
"""

__author__ = 'Kirill Python'
__version__ = '2.1'
__email__ = 'whoami@python273.pw'
__contact__ = 'https://vk.com/python273'

from .jconfig import Config
